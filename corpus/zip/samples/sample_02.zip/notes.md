# Notes

Stored, not deflated.
